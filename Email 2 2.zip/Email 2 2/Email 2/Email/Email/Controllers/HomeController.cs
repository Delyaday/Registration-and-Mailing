﻿using Email.Models;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using System.Diagnostics;
using System.IO;
using static System.Net.Mime.MediaTypeNames;

namespace Email.Controllers
{
    public class HomeController : Controller
    {

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult SendMessage()
        {
            string template = System.IO.File.ReadAllText(Path.Combine("Templates", "Template.html"));

            var emailService = new EmailService();
            var userEmail = HttpContext?.User?.Identity.Name;

            if (!string.IsNullOrEmpty(userEmail) && !string.IsNullOrEmpty(template))
            {
                template = template.Replace("{message}", "Привет");
                

                emailService.SendEmailAsync(userEmail, "Привет", template);
            }
            else
            {
                return Unauthorized("Пользователь не авторизован!");
            }

            return Ok("Сообщение отправлено!");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
